<?php
$xajax->processRequest();
?>